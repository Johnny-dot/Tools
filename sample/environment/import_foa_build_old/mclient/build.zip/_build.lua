-- foa 版本
version=293270

-- 合并bound到skl
function onEnumSklFile( filename )
	filename = 'king\\client\\' .. filename
	if filename:find( '.skl$' ) then
		local bound = filename:sub( 1, -5 ) .. '-bound.skn'
		_mf:buildSkeletonBoundSphere( filename, bound )
		_sys:delFile( bound )
	end
end
_sys:enumFile( 'king\\client', true, onEnumSklFile )

_sys.catchResError = false

---------------------------------------------------

local info = {
	name = "king",
	path = "king/client",
	code = "code/main.lua",
}

local paths = {
	-- 新资源
	'res',
	'res/audio',
	'res/char',
	'res/env',
	'res/env/skybox',
	'res/env/terrain',
	'res/env/textures',
	'res/env/water',
	'res/env/map',
	'res/mkr',
	'res/char/chm',
	'res/char/chf',
	'res/wep',
	'res/icon',
	'res/icon/face',
	'res/mon',
	'res/npc',
	'res/pet',
	'res/pfx',
	'res/textures',
	'res/swf',
	'code',
	-- 老资源
	'audio',
	'char',
	'env',
	'env/terrain',
	'env/roles',
	'env/object',
	'env/nature',
	'env/mainbuilding',
	'env/house',
	'env/skybox',
	'env/wall',
	'env/water',
	'env/pzl',
	'mkr',
	'char/chm',
	'char/chf',
	'wep',
	'icon',
	'icon/face',
	'mon',
	'npc',
	'pet',
	'pfx',
	'textures',
	'swf',
	'code',
}

local function addPath( )
	for i, v in ipairs( paths ) do _sys:addPath( v ) end
end

local function removePath( )
	for i, v in ipairs( paths ) do _sys:delPath( v ) end
end

local function lowertable( t )
	for k, v in pairs( t ) do t[k] = v:lower( ) end
end

-- 录制的needed
_dofile( 'neededcreate.lua' )

local dods = { "msh$", "skn$", "man$", "san$", "tga$", "bmp$", "jpg$", "dds$", "png$", "mp3$", "wav$", "sen$", "lay", "ttf$" }
local needed = { "lua$", ".lst$", ".shr$", ".cst$", ".occ$", "cur$", '.cfg$', ".mkr$", "skl$", "tag$", '.flt$', 'res.png$', 'default48.png',
'.gif$', 'dummy_1.msh', 'dummy_2.msh' }
local firsts = { ".gai$"}
local ignores = { "%.exe$", "%.fob$", "%.db$", "info$", "cfg$", 'txt$', '.svn', 'zip$', '.fla$', '$.tmp' }

-- needed, 所有tips, 帮助底板
local swfbase = {
}

local neededswf = {
	'login.swf',				-- 登录
	'login_2.swf',
	'k_choosejob.swf',			-- 选职业
	'creat_role.swf',			-- 创建角色
	'entergame.swf',			-- 进入游戏
	'msgbox.swf', 				-- msgbox
	'uiloader.swf',				-- ui基本加载器
	'uiloader2.swf',			-- 另一种
	'uiloader_msg.swf',			-- 第三种
	'uiloader_nobg.swf',		-- 第四种
	'loadingtemp.swf',			-- 默认的换场景swf
	'loadmov1.swf',				-- 过场动画加载中			
	'loadmov.swf',				
	'movie.swf',				-- 过场动画
	'circle.swf',				-- 加载
	'main_anime.swf',			-- 飘字
	'menu.swf',					-- 菜单
	'notice3.swf',				-- 公告
	'supremacy_tips.swf',		-- tip
}

local neededmusic = {
	'denglu.ogg','cangyun01.ogg','xieren01.ogg','meiniang01.ogg','qingluo01.ogg',
}

lowertable( dods )
lowertable( needed )
lowertable( firsts )
lowertable( ignores )
lowertable( swfbase )
lowertable( neededswf )

local neededlist = {
	needed,
	neededswf,
	neededmusic,
}

-- 录制结果
local neededlist2 = { neededcreate }
local neededlist3 = { }

for i, v in ipairs( neededlist2 ) do
	for i1, v1 in ipairs( v ) do
		neededlist3[i] = neededlist3[i] or { }
		neededlist3[i][i1] = _sys:getFileName( v1, true, false ):lower( )
	end
end

-- 前两个场景资源addPreGroup
local needscenelist = {
	--"enter_01",
	"xinshoucun",
	"zhucheng",
	"dianjiangtai",
	"ly",
}
local neededlistScene = { }
local neededlistSceneImg = { }
_dofile( 'pregroup_download.lua' )
for i, v in ipairs(needscenelist) do
	_dofile( v..'.lua' )
	_dofile( v..'_image.lua' )
	if _G[v] then
		for i1, v1 in ipairs( _G[v] ) do
			neededlistScene[i] = neededlistScene[i] or { }
			local index = i1
			neededlistScene[i][index] = neededlistScene[i][index] or { }
			neededlistScene[i][index].name = _sys:getFileName( v1, true, false ):lower( )
			neededlistScene[i][index].groupname = 'pregroup'..i..'_3'
		end
	end
	if _G.sceneRes[v] then
		for i1, v1 in ipairs( _G.sceneRes[v] ) do
			if type(v1) == 'table' then
				for index, value in ipairs(v1) do
					neededlistScene[i] = neededlistScene[i] or { }
					local index = #neededlistScene[i]+1
					neededlistScene[i][index] = neededlistScene[i][index] or { }
					neededlistScene[i][index].name = _sys:getFileName( value, true, false ):lower( )
					neededlistScene[i][index].groupname = 'pregroup'..i..'_1_'..i1
				end
			else
				neededlistScene[i] = neededlistScene[i] or { }
				local index = #neededlistScene[i]+1
				neededlistScene[i][index] = neededlistScene[i][index] or { }
				neededlistScene[i][index].name = _sys:getFileName( v1, true, false ):lower( )
				neededlistScene[i][index].groupname = 'pregroup'..i..'_1'
			end
		end
	end
	if _G.sceneRes2[v] then
		for i1, v1 in ipairs( _G.sceneRes2[v] ) do
			if type(v1) == 'table' then
				for index, value in ipairs(v1) do
					neededlistScene[i] = neededlistScene[i] or { }
					local index = #neededlistScene[i]+1
					neededlistScene[i][index] = neededlistScene[i][index] or { }
					neededlistScene[i][index].name = _sys:getFileName( value, true, false ):lower( )
					neededlistScene[i][index].groupname = 'pregroup'..i..'_2_'..i1
				end
			else
				neededlistScene[i] = neededlistScene[i] or { }
				local index = #neededlistScene[i]+1
				neededlistScene[i][index] = neededlistScene[i][index] or { }
				neededlistScene[i][index].name = _sys:getFileName( v1, true, false ):lower( )
				neededlistScene[i][index].groupname = 'pregroup'..i..'_2'
			end
		end
	end
	_dofile( v..'_monster.lua' )
	if _G[v..'_monster'] then
		for i1, v1 in ipairs( _G[v..'_monster'] ) do
			neededlistScene[i] = neededlistScene[i] or { }
			local index = #neededlistScene[i]+1
			neededlistScene[i][index] = neededlistScene[i][i1] or { }
			neededlistScene[i][index].name = _sys:getFileName( v1, true, false ):lower( )
			neededlistScene[i][index].groupname = 'pregroup'..i..'_4'
		end
	end
	--[[
	if _G[v..'_image'] then
		for i1, v1 in ipairs( _G[v..'_image'] ) do
			neededlistSceneImg[i] = neededlistSceneImg[i] or { }
			neededlistSceneImg[i][i1] = _sys:getFileName( v1, true, false ):lower( )
		end
	end]]
end

local function isTexture(n)
	n = n:lower()
	if n:find(".bmp$") or n:find(".jpg$") or n:find(".tga$") or n:find(".png$") then
		return true
	else
		return false
	end
end

local function needFormat(f)
	local needformat = false
	if isTexture(f) and f:find'textures' then
		for _, list in ipairs( neededlistSceneImg ) do
			for k, v in ipairs(list) do
				if f:find( v ) then
					needformat = true
					return needformat
				end
			end
		end
	end
	if f:find'.sen$' then
		for k, v in pairs(needscenelist) do
			if f:find(v) then
				needformat = true
				return needformat
			end
		end
	end
	return needformat
end

local types = { }
types['tga$'] = _Archive.TypeImage
types['bmp$'] = _Archive.TypeImage
types['jpg$'] = _Archive.TypeImage
types['dds$'] = _Archive.TypeImage
types['png$'] = _Archive.TypeImage
types['gif$'] = _Archive.TypeImage
types['skn$'] = _Archive.TypeMesh
types['msh$'] = _Archive.TypeMesh
types['san$'] = _Archive.TypeAnima
types['man$'] = _Archive.TypeAnima
types['sen$'] = _Archive.TypeScene
types['lua$'] = _Archive.TypeScript

local function infoformat( f, needformat )
	local res = 0
	--if f:find'textures' and not needformat then res = _Archive.TypeImageNoMip return res end
	for k, v in pairs( types ) do
		if string.find( f, k ) then res = v end
	end
	if f:find'icon' then res = _Archive.TypeImageNoMip end
	if res == _Archive.TypeImage and not needformat and (f:find'pet' or f:find'mon' or f:find'vassals' or f:find'ui3d') then res = _Archive.TypeImageNoMip end
	return res
end

local function packinfo( f )
	local fn = _sys:getFileName( f, true, false )
	local dod, fmt, pack

	fn = fn:lower( )
	f = f:lower( )

	---------------------- dod 异步下载 - msh/skn/san/bmp
	for k, v in next, dods do
		if v:find( fn ) then dod = '' break end
	end

	---------------------- pack 常驻内存 - pfx/skl/tag/gra
	if f:find'.pfx$' then pack = 'pfx' end
	if f:find'.skl$' then pack = 'skl' end
	if f:find'.tag$' then pack = 'tag' end
	if f:find'.inf$' then pack = 'inf' end
	if f:find'.gif$' then pack = 'gif' end
	if f:find'.gai$' then pack = 'gai' end

	---------------------- first 首包 - swf/ogg/录制
	for i, v in ipairs( swfbase ) do if f:find( v ) then dod = 'needed' end end
	for _, list in ipairs( neededlist ) do
		for k, v in ipairs( list ) do
			if f:find( v ) then dod = 'needed' break end
		end
		if dod == 'needed' then break end
	end
	for _, list in ipairs( neededlist3 ) do
		for k, v in ipairs( list ) do
			--法线贴图
			if ( fn:find( '-specular.png' ) or fn:find( '-normal.png' ) or fn:find( '-light.png' ) ) and v == fn then dod = 'needed' break end
			if v:find( fn ) then dod = 'needed' break end
		end
		if dod == 'needed' then break end
	end

	--打包之后先添加的组在前，后添加的在后
	local needformat = false
	for i, list in ipairs( neededlistScene ) do
		for k, v in ipairs(list) do
			if f:find( v.name ) then
				if not dod or dod == '' then dod = v.groupname end
				--只要info三个场景"xinshoucun","zhucheng","dianjiangtai",
				if i < 4 and f:find'textures' and isTexture(f) then needformat = true end
			break
		end
		if dod and dod ~= '' then break end
		end
	end

	---------------------- format信息
	fmt = infoformat( f, needformat )

	---------------------- 忽略的文件
	for k, v in next, ignores do
		if f:find( v ) then	fmt = nil break end
	end

	if f:find'swf\\login.swf' then dod = '' end
	if f:find'swf\\role.swf' then dod = '' end
	if f:find'swf\\zhangjie.swf' then dod = '' end
	if f:find'swf\\info.swf' then dod = '' end
	--版署关键字
	if f:find'keywords.flt' then dod = '' end

	return fmt, dod, pack
end

local archive = _Archive.new( );
archive.appTitle = info.name
archive.appName = info.name
archive.appVersion = version
archive.launchFile = info.code
archive.mainPlugin = 'fancy3d.fob'
archive:addPlugin'fancy3d.fob'
-- archive:addPlugin('>@king.fob')
archive.fileFolder = info.path.."\\";

------------------------------------------------------------DDS start
local function isDDS(filename)
	if not _sys:fileExist(filename) then return end

	local file = _File.new()
	file:open(filename)
	local s = file:read()
	file:close()

	local ddsflag = s:sub(1, 4)
	return ddsflag == 'DDS '
end

-- Pack img.xxx and img-alpha.xxx.
local imgDDS = function(respath,name)
	if not isTexture(name) then return end
	if name:find('-alpha') then return end

	local namenoext = name:sub(1, -5)
	local ext = name:sub(-4, -1)
	local alphaname = namenoext .. "-alpha" .. ext

	local resfile = respath .. name
	local alpfile = respath .. alphaname

	if not _sys:fileExist(alpfile) then return end

	local img = _Image.new(resfile)
	img:saveToFile(resfile)
	_sys:delFile(alpfile)

	print(string.format('==========Pack file \"%s\" \"%s\" --> \"%s\"', resfile, alpfile, resfile))
end

-- Convert textures.
command = "PVRTexTool.exe -silent -dds -fdxt%d -i \"%s\" -o \"%s\""
local textureDDS = function(respath,name)
	if not isTexture(name) then return end
	--alpha贴图不直接转dds,alpha贴图先执行imgDDS合成后再转dds
	if name:find('-alpha') then return end
	--[[if isDDS(name) then
		print(string.format('==========%s is already DDS.', name))
		return
	end]]

	local namenoext = name:sub(1, -5)
	local resfile = respath .. name
	local ddsname = respath .. namenoext .. ".dds"

	local format = _mf:isAlphaImage(resfile) and 3 or 1
	local cmd = string.format(command, format, resfile, ddsname)
	print(cmd)
	_sys:command(cmd, true, false)

	if not isDDS(ddsname) then
		print(string.format('++++++++++DDS convert failed, resname: \"%s\".', resfile))
	else
		_sys:moveFile(ddsname, resfile)
	end
end

-- Convert textures. 3D贴图加-m
command = "PVRTexTool.exe -silent -dds -fdxt%d -m -i \"%s\" -o \"%s\""
local textureDDS3D = function(respath,name)
	if not isTexture(name) then return end
	--alpha贴图不直接转dds,alpha贴图先执行imgDDS合成后再转dds
	if name:find('-alpha') then return end
	--[[if isDDS(name) then
		print(string.format('==========%s is already DDS.', name))
		return
	end]]

	local namenoext = name:sub(1, -5)
	local resfile = respath .. name
	local ddsname = respath .. namenoext .. ".dds"

	local format = _mf:isAlphaImage(resfile) and 3 or 1
	local cmd = string.format(command, format, resfile, ddsname)
	print(cmd)
	_sys:command(cmd, true, false)

	if not isDDS(ddsname) then
		print(string.format('++++++++++DDS convert failed, resname: \"%s\".', resfile))
	else
		_sys:moveFile(ddsname, resfile)
	end
end
------------------------------------------------------------DDS end

function onEnumFile( filename )
	local f = filename:lower( )
	local fmt, dod, pack = packinfo( f )
	if fmt == nil then return end

	--转DDS了不需要这一步
	if isTexture(filename) then
		if filename:find('icon') then
			--icon不转dds
		elseif string.find( f, ".dds" ) then
			imgDDS(info.path..'\\',f)
			textureDDS(info.path..'\\',f)
		else
			imgDDS(info.path..'\\',f)
			textureDDS3D(info.path..'\\',f)
		end
	elseif string.find( f, ".bmp" ) then
		-- bmp转jpg,转DDS了不需要这一步
		--_mf:changeImageFormat( info.path..'\\'..f, info.path..'\\'..f, _mf.ImageJpg, 100 )
	elseif string.find( f, ".san" ) then
		-- 优化动画资源
		_mf:optimizeSkeletonAnimation(f)
		-- 将tag文件的信息合并到动画文件中
		_mf:checkAnimation( f )
	elseif string.find( f, ".skn" ) or string.find( f, ".msh" ) then
		-- 优化模型资源
		_mf:optimizeMesh(f)
	elseif string.find( f, '.swf' ) then
		local fn = _sys:getFileName( f, true, false )
		fn = string.lower( fn )
		archive:addFile( f, nil, fmt )
	end

	if not pack then
		archive:addFile( f, tostring( dod ), fmt )
	else
		archive:addPack( f, pack, f )
	end
end

addPath( )
_sys:enumFile( info.path, true, onEnumFile )
removePath( )
--添加分组。打包之后先添加的组在前，后添加的在后. needed可以写也可以不写，引擎会处理。其他的分组需要写.
--[[for i, list in ipairs( neededlistScene ) do
	archive:addPreGroup('pregroup'..i)
end]]
for i, v in ipairs(needscenelist) do
	if _G.sceneRes[v] then
		for i1, v1 in ipairs( _G.sceneRes[v] ) do
			if type(v1) == 'table' then
				archive:addPreGroup('pregroup'..i..'_1_'..i1)
			else
				archive:addPreGroup('pregroup'..i..'_1')
			end
		end
	end
	if _G.sceneRes2[v] then
		for i1, v1 in ipairs( _G.sceneRes2[v] ) do
			if type(v1) == 'table' then
				archive:addPreGroup('pregroup'..i..'_2_'..i1)
			else
				archive:addPreGroup('pregroup'..i..'_2')
			end
		end
	end
	if _G[v] then
		archive:addPreGroup('pregroup'..i..'_3')
	end
	if _G[v..'_monster'] then
		archive:addPreGroup('pregroup'..i..'_4')
	end
	--[[
	if _G[v..'_image'] then
		for i1, v1 in ipairs( _G[v..'_image'] ) do
			neededlistSceneImg[i] = neededlistSceneImg[i] or { }
			neededlistSceneImg[i][i1] = _sys:getFileName( v1, true, false ):lower( )
		end
	end]]
end
archive.compressMode = _Archive.Compress7z
archive:save( "king" .. "-foa-" .. version ..".zip", "check.txt", "6a7bf9ad539301d1795155eca6425e7f" )